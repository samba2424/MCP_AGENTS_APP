# MCP Agents App

Cette application Express est prête à être déployée sur Render, avec des endpoints simples et des intégrations IA prêtes.

## Démarrage

```bash
npm install
npm start
```

Modifie `.env` pour ajouter tes clés OpenAI ou Webhooks.